import time
import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from datasets import Dataset
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import torch
import numpy as np

# Set the device to MPS explicitly if available, else fall back to CPU
device = torch.device("mps") if torch.backends.mps.is_available() else torch.device("cpu")

# Load dataset
print("Loading dataset...")
file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset (Fine tuning).csv'
data = pd.read_csv(file_path)
print(f"Dataset loaded with {len(data)} entries.")

# Drop rows with missing values
print("Dropping rows with missing values...")
data = data.dropna(subset=['Question', 'Answer'])
print(f"Remaining dataset size: {len(data)}")

# Further reduce the dataset size for testing purposes
reduction_frac = 0.5  # 50% of the data for fine-tuning
reduced_data = data.sample(frac=reduction_frac, random_state=42)
print(f"Using {int(reduction_frac * 100)}% of the dataset for fine-tuning...")
print(f"Reduced dataset size: {len(reduced_data)}")

# Initialize the tokenizer and model
print("Loading model and tokenizer for distilgpt2...\n")
model_name = "distilgpt2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
tokenizer.pad_token = tokenizer.eos_token  # Set the pad token as the EOS token
model = AutoModelForCausalLM.from_pretrained(model_name).to(device)  # Move model to MPS/CPU
print("Model and tokenizer loaded.")

# Prepare the dataset
def preprocess_function(examples):
    inputs = [question + " " + answer for question, answer in zip(examples['Question'], examples['Answer'])]
    model_inputs = tokenizer(inputs, max_length=512, truncation=True, padding="max_length")
    model_inputs["labels"] = model_inputs["input_ids"].copy()
    return model_inputs

# Convert to Dataset object
print("Tokenizing dataset...")
reduced_dataset = Dataset.from_pandas(reduced_data)
tokenized_reduced_dataset = reduced_dataset.map(preprocess_function, batched=True)
print("Dataset tokenized.")

# Fine-tune the model
training_args = TrainingArguments(
    output_dir="./fine_tuned_distilgpt2",
    evaluation_strategy="no",
    learning_rate=2e-5,
    per_device_train_batch_size=1,
    num_train_epochs=3,
    weight_decay=0.01
)

print("Initializing Trainer...")
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_reduced_dataset,
)
print("Trainer initialized.")

print("Starting fine-tuning...")
trainer.train()
print("Fine-tuning completed.")

# Save the model
print("Saving fine-tuned model...")
trainer.save_model("./fine_tuned_distilgpt2")
tokenizer.save_pretrained("./fine_tuned_distilgpt2")
print("Model saved.")

# Evaluate model performance
print("\nEvaluating model performance...")
num_samples = min(len(reduced_data), 5)  # Ensure we don't sample more than what's available
sample_data = reduced_data.sample(n=num_samples, random_state=42)  # Select a subset of data for evaluation
similarity_threshold = 0.7

# Dictionary to store performance metrics
performance_metrics = {}

def evaluate_finetuned_model(model_name):
    start_time = time.time()
    generated_responses = []

    for question in sample_data['Question']:
        inputs = tokenizer.encode(question, return_tensors="pt").to(device)  # Ensure inputs are on MPS/CPU
        attention_mask = inputs.ne(tokenizer.pad_token_id).to(device)  # Create attention mask
        outputs = model.generate(inputs, attention_mask=attention_mask, max_length=150, pad_token_id=tokenizer.eos_token_id)
        generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        print(f"Generated response for '{question}': {generated_text}")
        generated_responses.append(generated_text)

    embedding_model = SentenceTransformer('sentence-transformers/all-mpnet-base-v2')
    response_embeddings = embedding_model.encode(generated_responses, show_progress_bar=True)
    end_time = time.time()

    similarities = []
    correct_predictions = 0

    for i, question in enumerate(sample_data['Question']):
        question_embedding = embedding_model.encode([question])[0]
        response_embedding = response_embeddings[i]
        similarity = cosine_similarity([question_embedding], [response_embedding])[0][0]
        similarities.append(similarity)
        print(f"Similarity for question '{question}': {similarity}")

        if similarity > similarity_threshold:
            correct_predictions += 1

    avg_similarity = np.mean(similarities)
    runtime = end_time - start_time
    accuracy = correct_predictions / len(sample_data)

    performance_metrics[model_name] = {
        "average_similarity": avg_similarity,
        "runtime": runtime,
        "accuracy": accuracy
    }

# Evaluate the fine-tuned model
evaluate_finetuned_model("Fine-tuned GPT-2")

# Display performance metrics
print("\n--- Performance Metrics ---")
for model_name, metrics in performance_metrics.items():
    print(f"Model: {model_name}")
    print(f"Average Similarity: {metrics['average_similarity']}")
    print(f"Runtime: {metrics['runtime']} seconds")
    print(f"Accuracy: {metrics['accuracy'] * 100:.2f}%")
