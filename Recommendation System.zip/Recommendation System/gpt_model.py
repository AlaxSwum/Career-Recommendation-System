import openai
import os
import pandas as pd
import streamlit as st
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import time

# Set your OpenAI API key
openai.api_key = 'sk-None-knJq65nMz6FYYyinicLoT3BlbkFJPD0E1cQWOT2hEMUUU0N7'  # Replace with your actual API key

# File paths - Adjust these as per your environment
csv_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset.csv'
parquet_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset.parquet'
dataset_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/recommendation_dataset'

# Function to convert CSV to Parquet
@st.cache_data
def convert_csv_to_parquet(csv_path, parquet_path):
    if not os.path.exists(parquet_path):
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"CSV file not found: {csv_path}")
        df = pd.read_csv(csv_path)
        df.to_parquet(parquet_path)
    return parquet_path

# Load data in chunks
@st.cache_data
def load_data(parquet_path):
    try:
        df = pd.read_parquet(parquet_path)
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

# Function to get a response from GPT-3.5-Turbo
def get_gpt35_turbo_response(prompt):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=150,
            temperature=0.7
        )
        return response.choices[0]['message']['content'].strip()
    except openai.error.RateLimitError as e:
        st.error(f"Rate limit exceeded: {e}")
        return "Rate limit exceeded. Please try again later."
    except openai.error.OpenAIError as e:
        st.error(f"An error occurred: {e}")
        return "An error occurred. Please try again later."

# Main function for Streamlit
def main():
    st.title("GPT-3.5-Turbo Career Recommendation System")

    # Ensure the current working directory is correct
    print("Current Working Directory:", os.getcwd())

    # Convert CSV to Parquet and load data
    parquet_path = convert_csv_to_parquet(csv_file_path, parquet_file_path)
    df = load_data(parquet_path)
    if df is None:
        st.error("Failed to load data.")
        return
    
    # Load sample data for potential evaluation purposes
    sample_data = df.sample(n=5, random_state=42)

    # Initialize session state
    if 'history' not in st.session_state:
        st.session_state['history'] = []
    if 'last_response' not in st.session_state:
        st.session_state['last_response'] = (None, None, None)

    # User input field
    user_input = st.text_input("Your Career Question", placeholder="Type your message here...")

    # Handling the send button click event
    if st.button("Send"):
        if user_input:
            # Log the user question
            st.session_state['history'].append(("You", user_input))
            with st.spinner("Getting response from GPT-3.5-Turbo..."):
                start_time = time.time()
                response = get_gpt35_turbo_response(user_input)
                response_time = time.time() - start_time

                # Log the response from GPT-3.5-Turbo
                st.session_state['history'].append(("GPT-3.5-Turbo", response))
                st.write(f"Response time: {response_time:.4f} seconds")

                # Display chat history
                for chat in st.session_state['history']:
                    st.write(f"**{chat[0]}**: {chat[1]}")

                # Store last response for feedback or further processing
                st.session_state['last_response'] = (user_input, response, response_time)

    # User feedback section
    if st.session_state['last_response'][0]:
        st.write("Was this response helpful?")
        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("Yes"):
                st.write("Thank you for your feedback!")
                st.session_state['last_response'] = (None, None, None)
        with col2:
            if st.button("No"):
                st.write("We'll improve our responses!")
                st.session_state['last_response'] = (None, None, None)

if __name__ == "__main__":
    main()
