import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from datasets import Dataset
import torch
from torch.quantization import quantize_dynamic

# Define the file path to your dataset
file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset (Fine tuning).csv'

# Load the dataset
data = pd.read_csv(file_path)

# Drop rows with missing values in 'Question' and 'Answer' columns
data = data.dropna(subset=['Question', 'Answer'])

# Further reduce the dataset size to 1% of the original data
reduced_data = data.sample(frac=0.01, random_state=42)  # Adjust the fraction as needed

# Initialize the tokenizer and model
model_name = "mistralai/Mistral-7B-Instruct-v0.1"  # Continue using Mistral model
tokenizer = AutoTokenizer.from_pretrained(model_name)  # Use '=' instead of 'is'
model = AutoModelForCausalLM.from_pretrained(model_name)  # Use '=' instead of 'is'

# Enable gradient checkpointing and disable caching for training efficiency
model.gradient_checkpointing_enable()
model.config.use_cache = False

# Prepare the dataset for training
def preprocess_function(examples):
    # Concatenate question and answer for language model training
    inputs = [question + " " + answer for question, answer in zip(examples['Question'], examples['Answer'])]
    model_inputs = tokenizer(inputs, max_length=512, truncation=True)
    model_inputs["labels"] = model_inputs["input_ids"].copy()
    return model_inputs

# Convert the reduced pandas DataFrame into a Dataset object and tokenize it
reduced_dataset = Dataset.from_pandas(reduced_data)
tokenized_reduced_dataset = reduced_dataset.map(preprocess_function, batched=True, remove_columns=["ID", "Question", "Answer"])

# Define training arguments with adjusted settings
training_args = TrainingArguments(
    output_dir="./fine_tuned_mistral_model",
    eval_strategy="epoch",  # Updated from evaluation_strategy to eval_strategy
    learning_rate=2e-5,
    per_device_train_batch_size=1,  # Keep batch size at minimum to manage memory
    per_device_eval_batch_size=1,
    num_train_epochs=2,  # Reduce epochs to speed up training
    weight_decay=0.01,
    save_total_limit=2,
    gradient_accumulation_steps=8,  # Accumulate gradients over multiple steps
    logging_steps=50,  # Reduce logging frequency to minimize I/O overhead
    dataloader_num_workers=4,  # Use multiple workers to load data in parallel
    no_cuda=True,  # Ensure that the model doesn't attempt to use CUDA (since you're on Apple Silicon)
)

# Initialize the Trainer with efficient settings
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_reduced_dataset,
)

# Fine-tune the model
trainer.train()

# Quantize the fine-tuned model after training for inference
quantized_model = quantize_dynamic(
    model,  # The trained model
    {torch.nn.Linear},  # Layers to apply dynamic quantization (linear layers)
    dtype=torch.qint8  # Quantize to 8-bit integers
)

# Save the quantized model and tokenizer
quantized_model.save_pretrained("./fine_tuned_mistral_model_quantized")
tokenizer.save_pretrained("./fine_tuned_mistral_model_quantized")
