import os
import pandas as pd
from datasets import Dataset
from sentence_transformers import SentenceTransformer

csv_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset.csv'
parquet_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset.parquet'
dataset_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/recommendation_dataset'
index_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/recommendation_index/faiss_index'

# Function to convert CSV to Parquet
def convert_csv_to_parquet(csv_file_path, parquet_file_path):
    if not os.path.exists(parquet_file_path):
        if not os.path.exists(csv_file_path):
            raise FileNotFoundError(f"CSV file not found: {csv_file_path}")
        df = pd.read_csv(csv_file_path)
        df.to_parquet(parquet_file_path)
    return parquet_file_path

# Load data in chunks
def load_data(parquet_file_path):
    try:
        df = pd.read_parquet(parquet_file_path)
        return df
    except Exception as e:
        raise Exception(f"Error loading data: {e}")

# Convert to embeddings
def convert_to_embeddings(df, column, model_name='sentence-transformers/all-mpnet-base-v2'):
    try:
        print(f"Loading model: {model_name}")
        model = SentenceTransformer(model_name)
        if model is None:
            raise ValueError(f"Model {model_name} could not be loaded.")
        
        print(f"Encoding texts from column: {column}")
        texts = df[column].tolist()
        print(f"Sample text: {texts[:5]}")  # Print a few samples to verify the data
        
        # Check for any empty strings in the texts
        empty_texts = [i for i, text in enumerate(texts) if not text]
        if empty_texts:
            raise ValueError(f"Empty texts found at indices: {empty_texts}")
        
        embeddings = model.encode(texts, show_progress_bar=True)
        if embeddings is None or len(embeddings) == 0:
            raise ValueError("Embeddings are None or empty.")
        
        # Log some of the embeddings to verify
        print(f"Sample embeddings: {embeddings[:5]}")
        
        df['embeddings'] = embeddings.tolist()  # Ensure the embeddings are a list of arrays
        return df
    except Exception as e:
        raise Exception(f"Error converting to embeddings: {e}")

# Prepare dataset
def prepare_dataset(parquet_file_path, dataset_path, index_file_path):
    df = load_data(parquet_file_path)
    
    # Print columns for debugging
    print(f"Columns in the DataFrame: {df.columns}")
    
    # Drop rows with empty 'Question' values
    df = df.dropna(subset=['Question'])
    df = df[df['Question'].str.strip().astype(bool)]
    
    df = convert_to_embeddings(df, 'Question')  # Updated to 'Question'
    
    # Ensure embeddings are of correct type
    df['embeddings'] = df['embeddings'].apply(lambda x: x if isinstance(x, list) else x.tolist())
    
    # Rename columns to match the expected format
    df.rename(columns={'Question': 'title', 'Answer': 'text'}, inplace=True)
    
    # Drop the index column if it exists
    if '__index_level_0__' in df.columns:
        df.drop(columns=['__index_level_0__'], inplace=True)
    
    # Create dataset
    dataset = Dataset.from_pandas(df[['title', 'text', 'embeddings']])
    
    # Drop any existing indexes if present
    if 'embeddings' in dataset._indexes:
        dataset.drop_index('embeddings')
    
    # Save dataset and index
    dataset.save_to_disk(dataset_path)
    dataset.add_faiss_index(column='embeddings')
    dataset.save_faiss_index(index_name='embeddings', file=index_file_path)

# Main execution
if __name__ == "__main__":
    try:
        parquet_file_path = convert_csv_to_parquet(csv_file_path, parquet_file_path)
        prepare_dataset(parquet_file_path, dataset_path, index_file_path)
    except FileNotFoundError as e:
        print(e)
    except Exception as e:
        print(f"An error occurred: {e}")
