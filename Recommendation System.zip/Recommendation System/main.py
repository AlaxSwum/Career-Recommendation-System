import os
import pandas as pd
import streamlit as st
from transformers import AutoTokenizer, AutoModelForCausalLM, RagRetriever, RagSequenceForGeneration
from datasets import Dataset, load_from_disk
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import torch

# Ensure the current working directory is correct
print("Current Working Directory:", os.getcwd())

# File paths - Adjust these as per your environment
csv_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset.csv'
parquet_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/Career Dataset - Dataset.parquet'
dataset_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/recommendation_dataset'
index_file_path = '/Users/swumpyaesone/Documents/Northumbria University/UG project/recommendation_index/faiss_index'

# Function to convert CSV to Parquet
@st.cache_data
def convert_csv_to_parquet(csv_file_path, parquet_file_path):
    if not os.path.exists(parquet_file_path):
        if not os.path.exists(csv_file_path):
            raise FileNotFoundError(f"CSV file not found: {csv_file_path}")
        df = pd.read_csv(csv_file_path)
        df.to_parquet(parquet_file_path)
    return parquet_file_path

# Load data in chunks
@st.cache_data
def load_data(parquet_file_path):
    try:
        df = pd.read_parquet(parquet_file_path)
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

# Setup models
@st.cache_resource
def setup_models(dataset_path, index_file_path):
    retriever = RagRetriever.from_pretrained(
        "facebook/rag-sequence-nq",
        index_name="custom",
        use_dummy_dataset=False,
        index_path=index_file_path,
        passages_path=dataset_path
    )
    tokenizer_rag = AutoTokenizer.from_pretrained("facebook/rag-sequence-nq")
    model_rag = RagSequenceForGeneration.from_pretrained(
        "facebook/rag-sequence-nq", retriever=retriever
    )
    
    model_name = "mistralai/Mistral-7B-Instruct-v0.1"
    tokenizer_mistral = AutoTokenizer.from_pretrained(model_name)
    model_mistral = AutoModelForCausalLM.from_pretrained(model_name)
    
    return tokenizer_rag, model_rag, retriever, tokenizer_mistral, model_mistral

# Convert to embeddings
@st.cache_data
def convert_to_embeddings(df, column, model_name='sentence-transformers/all-mpnet-base-v2'):
    try:
        model = SentenceTransformer(model_name)
        embeddings = model.encode(df[column].tolist(), show_progress_bar=True)
        df['embeddings'] = embeddings.tolist()  # Ensure the embeddings are a list of arrays
        return df
    except Exception as e:
        st.error(f"Error converting to embeddings: {e}")
        return None

# Prepare dataset
@st.cache_resource
def prepare_dataset(parquet_file_path, dataset_path, index_file_path):
    df = load_data(parquet_file_path)
    if df is None:
        raise ValueError("Failed to load data")
    
    df = convert_to_embeddings(df, 'title')
    if df is None:
        raise ValueError("Failed to convert data to embeddings")
    
    # Ensure embeddings are of correct type
    df['embeddings'] = df['embeddings'].apply(lambda x: x if isinstance(x, list) else x.tolist())
    
    # Create dataset
    dataset = Dataset.from_pandas(df[['title', 'text', 'embeddings']])
    
    # Drop any existing indexes if present
    if 'embeddings' in dataset._indexes:
        dataset.drop_index('embeddings')
    
    # Save dataset and index
    dataset.save_to_disk(dataset_path)
    dataset.add_faiss_index(column='embeddings')
    dataset.save_faiss_index(index_name='embeddings', file=index_file_path)

# Keyword-based matching function
def keyword_match_response(user_input, df):
    user_input = user_input.lower()
    for index, row in df.iterrows():
        title = row['title'].lower()  # Use the 'title' column for matching
        if title in user_input:
            return row['text']  # Return the corresponding text if a match is found
    return None  # Return None if no match is found

# Get response from RAG model
def get_response(question, dataset, tokenizer_rag, model_rag, retriever):
    try:
        df = dataset.to_pandas()
        questions = df['title'].tolist()

        # Compute embeddings for the input question
        model = SentenceTransformer('sentence-transformers/all-mpnet-base-v2')
        question_embedding = model.encode([question])

        # Compute cosine similarity with dataset questions
        similarities = cosine_similarity(question_embedding, np.vstack(df['embeddings']))
        closest_index = np.argmax(similarities)
        closest_match = questions[closest_index]
        closest_score = similarities[0, closest_index]

        # Use threshold to decide whether to use a matched response or generate a new one
        if closest_score > 0.8:
            response = df[df['title'] == closest_match]['text'].values[0]
        else:
            inputs = tokenizer_rag(question, return_tensors="pt")
            with torch.no_grad():
                outputs = model_rag.generate(input_ids=inputs['input_ids'], max_length=500)
            response = tokenizer_rag.decode(outputs[0], skip_special_tokens=True)
        
        # Store response and similarity score for feedback loop
        st.session_state['last_response'] = (question, response, closest_score)
        return response
    except Exception as e:
        st.error(f"Error generating response from RAG model: {e}")
        return "I'm sorry, I couldn't process your request."

# Generate response with Mistral model
@st.cache_data
def generate_response_mistral(_tokenizer, _model, question, device='cpu'):
    try:
        _model.to(device)
        inputs = _tokenizer.encode(question, return_tensors="pt").to(device)
        with torch.no_grad():
            outputs = _model.generate(inputs, max_length=150)
        return _tokenizer.decode(outputs[0], skip_special_tokens=True)
    except Exception as e:
        st.error(f"Error generating response from Mistral model: {e}")
        return "I'm sorry, I couldn't process your request."

# Main function for Streamlit
def main():
    global parquet_file_path
    parquet_file_path = convert_csv_to_parquet(csv_file_path, parquet_file_path)
    
    if not os.path.exists(dataset_path):
        prepare_dataset(parquet_file_path, dataset_path, index_file_path)
    
    try:
        dataset = load_from_disk(dataset_path)
    except Exception as e:
        st.error(f"Error loading dataset from disk: {e}")
        return
    
    tokenizer_rag, model_rag, retriever, tokenizer_mistral, model_mistral = setup_models(dataset_path, index_file_path)
    
    st.title("Talk to Me Career!")
    
    if 'history' not in st.session_state:
        st.session_state['history'] = []
    if 'last_response' not in st.session_state:
        st.session_state['last_response'] = (None, None, None)

    # Display chat history
    for chat in st.session_state['history']:
        if chat[0] == 'You':
            st.chat_message("user").markdown(f"**{chat[0]}**: {chat[1]}")
        else:
            st.chat_message("assistant").markdown(f"**{chat[0]}**: {chat[1]}")

    # User input
    with st.container():
        with st.form(key='input_form', clear_on_submit=True):
            user_input = st.text_area("Your Career Recommendation System", placeholder="Type your message here...", key='input')
            submit_button = st.form_submit_button('Send')
        
        if submit_button and user_input:
            st.session_state['history'].append(("You", user_input))
            
            # Attempt to match using keywords
            response = keyword_match_response(user_input, dataset.to_pandas())
            
            # If no keyword match found, use RAG model
            if response is None:
                try:
                    response = get_response(user_input, dataset, tokenizer_rag, model_rag, retriever)
                    st.session_state['history'].append(("AI (RAG)", response))
                except Exception as e:
                    st.error(f"Error generating response, using fallback: {e}")
                    response = generate_response_mistral(tokenizer_mistral, model_mistral, user_input)
                    st.session_state['history'].append(("AI (Fallback)", response))
            else:
                st.session_state['history'].append(("AI (Keyword Match)", response))
            
            st.experimental_rerun()

    # Feedback
    if st.session_state['last_response'][0]:
        st.write("Was this response helpful?")
        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("Yes"):
                st.write("Thank you for your feedback!")
                st.session_state['last_response'] = (None, None, None)
        with col2:
            if st.button("No"):
                st.write("We'll improve our responses!")
                st.session_state['last_response'] = (None, None, None)
    
    st.markdown('<div class="chat-box">', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    main()
